//declare the play function
int play(void);