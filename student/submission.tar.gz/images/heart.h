/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=20x20 images/heart images/heart.png 
 * Time-stamp: Wednesday 07/08/2020, 04:11:16
 * 
 * Image Information
 * -----------------
 * images/heart.png 20@20
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef HEART_H
#define HEART_H

extern const unsigned short heart[400];
#define HEART_SIZE 800
#define HEART_LENGTH 400
#define HEART_WIDTH 20
#define HEART_HEIGHT 20

#endif

