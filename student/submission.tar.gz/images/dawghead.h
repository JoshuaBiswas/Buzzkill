/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=20x20 images/dawghead images/dawghead.png 
 * Time-stamp: Wednesday 07/08/2020, 04:11:54
 * 
 * Image Information
 * -----------------
 * images/dawghead.png 20@20
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef DAWGHEAD_H
#define DAWGHEAD_H

extern const unsigned short dawghead[400];
#define DAWGHEAD_SIZE 800
#define DAWGHEAD_LENGTH 400
#define DAWGHEAD_WIDTH 20
#define DAWGHEAD_HEIGHT 20

#endif

