/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=20x20 images/dawg images/dawg.png 
 * Time-stamp: Thursday 07/09/2020, 16:07:21
 * 
 * Image Information
 * -----------------
 * images/dawg.png 20@20
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef DAWG_H
#define DAWG_H

extern const unsigned short dawg[400];
#define DAWG_SIZE 800
#define DAWG_LENGTH 400
#define DAWG_WIDTH 20
#define DAWG_HEIGHT 20

#endif

