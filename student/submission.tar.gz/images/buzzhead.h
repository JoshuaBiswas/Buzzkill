/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=20x20 images/buzzhead images/buzzhead.png 
 * Time-stamp: Wednesday 07/08/2020, 04:11:02
 * 
 * Image Information
 * -----------------
 * images/buzzhead.png 20@20
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BUZZHEAD_H
#define BUZZHEAD_H

extern const unsigned short buzzhead[400];
#define BUZZHEAD_SIZE 800
#define BUZZHEAD_LENGTH 400
#define BUZZHEAD_WIDTH 20
#define BUZZHEAD_HEIGHT 20

#endif

