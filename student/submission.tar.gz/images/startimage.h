/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 images/startimage images/startimage.png 
 * Time-stamp: Sunday 07/12/2020, 19:43:41
 * 
 * Image Information
 * -----------------
 * images/startimage.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef STARTIMAGE_H
#define STARTIMAGE_H

extern const unsigned short startimage[38400];
#define STARTIMAGE_SIZE 76800
#define STARTIMAGE_LENGTH 38400
#define STARTIMAGE_WIDTH 240
#define STARTIMAGE_HEIGHT 160

#endif

