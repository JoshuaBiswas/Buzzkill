/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 images/winimage images/winimage.png 
 * Time-stamp: Sunday 07/12/2020, 19:43:54
 * 
 * Image Information
 * -----------------
 * images/winimage.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef WINIMAGE_H
#define WINIMAGE_H

extern const unsigned short winimage[38400];
#define WINIMAGE_SIZE 76800
#define WINIMAGE_LENGTH 38400
#define WINIMAGE_WIDTH 240
#define WINIMAGE_HEIGHT 160

#endif

