/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=20x20 images/yellowjacket images/yellowjacket.png 
 * Time-stamp: Wednesday 07/08/2020, 04:55:40
 * 
 * Image Information
 * -----------------
 * images/yellowjacket.png 20@20
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef YELLOWJACKET_H
#define YELLOWJACKET_H

extern const unsigned short yellowjacket[400];
#define YELLOWJACKET_SIZE 800
#define YELLOWJACKET_LENGTH 400
#define YELLOWJACKET_WIDTH 20
#define YELLOWJACKET_HEIGHT 20

#endif

