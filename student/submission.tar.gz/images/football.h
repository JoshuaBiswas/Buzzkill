/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=20x12 images/football images/football.png 
 * Time-stamp: Thursday 07/09/2020, 18:57:26
 * 
 * Image Information
 * -----------------
 * images/football.png 20@12
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef FOOTBALL_H
#define FOOTBALL_H

extern const unsigned short football[240];
#define FOOTBALL_SIZE 480
#define FOOTBALL_LENGTH 240
#define FOOTBALL_WIDTH 20
#define FOOTBALL_HEIGHT 12

#endif

