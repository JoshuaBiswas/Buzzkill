/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=20x20 images/emptyheart images/emptyheart.png 
 * Time-stamp: Wednesday 07/08/2020, 04:11:38
 * 
 * Image Information
 * -----------------
 * images/emptyheart.png 20@20
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef EMPTYHEART_H
#define EMPTYHEART_H

extern const unsigned short emptyheart[400];
#define EMPTYHEART_SIZE 800
#define EMPTYHEART_LENGTH 400
#define EMPTYHEART_WIDTH 20
#define EMPTYHEART_HEIGHT 20

#endif

