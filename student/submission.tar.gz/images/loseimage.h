/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 images/loseimage images/loseimage.png 
 * Time-stamp: Sunday 07/12/2020, 19:44:08
 * 
 * Image Information
 * -----------------
 * images/loseimage.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef LOSEIMAGE_H
#define LOSEIMAGE_H

extern const unsigned short loseimage[38400];
#define LOSEIMAGE_SIZE 76800
#define LOSEIMAGE_LENGTH 38400
#define LOSEIMAGE_WIDTH 240
#define LOSEIMAGE_HEIGHT 160

#endif

